from distutils.core import setup
setup(name='wordipy',
      version='0.1',
      py_modules=['wordipy'],
      )
